<template>
  <div class="header-wrap flex flex-row pl-10 items-center"><router-link to="/" ><img src="@/assets/images/logo.png" /></router-link></div>
</template>
<script lang="ts" setup></script>
<style lang="less" scope>
.header-wrap {
  height: 60px;
  a,img{
    height: 100%;
  }
}
</style>
