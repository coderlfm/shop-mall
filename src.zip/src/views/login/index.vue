<template>
  <LoginHeader />
  <LoginMain />
</template>
<script lang="ts" setup>
// import { ref, defineComponent } from 'vue';
import LoginHeader from './header/index.vue';
import LoginMain from './main/index.vue';

// function a() {
//   let;
// }
// defineComponent([LoginHeader, LoginMain]);
// const color = ref('red');
</script>
<style>
/* set */
</style>
