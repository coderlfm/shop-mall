<template lang="">
  <div>
    <Swiper />
    <main class="main-w mx-auto overflow-hidden">
      <HomeMain />
    </main>
  </div>
</template>
<script lang="ts" setup>
import Swiper from './swiper/index.vue';
import HomeMain from './main/index.vue';
</script>
<style lang=""></style>
