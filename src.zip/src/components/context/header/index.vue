<template lang="">
  <NarBar />
  <SearchBar />
</template>

<script lang="ts" setup>
import NarBar from './nav-bar/index.vue';
import SearchBar from './search-bar/index.vue';
</script>
<style lang="less" scoped></style>
