import Swiper from './swiper/index.vue';
import Modal from './modal/index.vue';

export { Swiper, Modal };
