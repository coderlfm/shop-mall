export const SALT = 'tea'; //盐值
export const ACCOUNT_DEFAULT_PASSWORD = '123456'; // 账号默认密码
