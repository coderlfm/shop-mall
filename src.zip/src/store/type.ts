export interface IRootStore {
  userInfo: any;
  userAddress: any;
}
